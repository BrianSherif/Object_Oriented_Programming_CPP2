/*
CH08-320142
a6_p3
Brian Sherif Nazmi Hanna Nasralla
B.hannanasralla@jacobs-university.de
*/
#ifndef FRACTION_H_
#define FRACTION_H_

class Fraction {

private:
    int num;
    int den;
    std::string fra;
public:
    Fraction();//Empty constructor
    Fraction(const Fraction&);//copy constructor
    Fraction(int, int = 1);//parameter constructor
    Fraction(const std::string&);
    ~Fraction(){};//destructor


    //operator overloading
    friend std::ostream& operator<<(std::ostream&, const Fraction&);
    friend std::istream& operator>>(std::istream&, Fraction&);
    Fraction operator+(const Fraction&);
    Fraction operator-(const Fraction&);
    Fraction operator=(const Fraction&);
    Fraction operator*(const Fraction&);
    Fraction operator/(const Fraction&);
    bool operator<(const Fraction&);
    bool operator>(const Fraction&);
    bool operator<=(const Fraction&);
    bool operator>=(const Fraction&);
    bool operator==(const Fraction&);
    bool operator!=(const Fraction&);

    //print function
    void print();
};
#endif
